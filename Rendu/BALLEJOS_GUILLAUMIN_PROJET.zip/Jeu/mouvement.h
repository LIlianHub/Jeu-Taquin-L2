void DetectZero(int ** tab, int dim, int * x, int * y);
int MouvDroite(int ** tab, int dim);
int MouvGauche(int ** tab, int dim);
int MouvBas(int ** tab, int dim);
int MouvHaut(int ** tab, int dim);