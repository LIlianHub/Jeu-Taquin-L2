int ** ChargementPatern(char PaternVoulu[15],int * dim);
void FreeTab(int ** tab, int dim);
int ** AlloueTab(int dim);
void afficheTab(int ** tab, int dim);
int CompareTab(int ** tab, int dim);
int ** GenereId(int dim);
int ** GenereTabRandom(int dim);